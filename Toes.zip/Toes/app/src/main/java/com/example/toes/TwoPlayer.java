package com.example.toes;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class TwoPlayer extends AppCompatActivity {
    TextView textView1;
    TextView textView2;
    TextView textView3;
    TextView textView4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView1 = (TextView) findViewById(R.id.textView1);
        textView2 = (TextView) findViewById(R.id.textView2);
        textView3 = (TextView) findViewById(R.id.textView3);
        textView4 = (TextView) findViewById(R.id.textView4);

    }

    int counter = 1;
    int winner = 0;
    public void button_click(View view) {
        Button button_select = (Button) view;
        int ID = 0;
        switch (button_select.getId()){
            case R.id.button1: ID = 1;break;
            case R.id.button2: ID = 2;break;
            case R.id.button3: ID = 3;break;
            case R.id.button4: ID = 4;break;
            case R.id.button5: ID = 5;break;
            case R.id.button6: ID = 6;break;
            case R.id.button7: ID = 7;break;
            case R.id.button8: ID = 8;break;
            case R.id.button9: ID = 9;break;
        }
        button_select.setEnabled(false);
        if (winner == 0) {
            counter++;
            game(button_select,ID);
            check_winner();
        }
    }

    int Active_player = 1;
    ArrayList<Integer> player1 = new ArrayList<>();
    ArrayList <Integer> player2 = new ArrayList<>();

    public void game (Button button_select,int ID){
        if (Active_player == 1) {
            player1.add(ID);
            button_select.setTextColor(Color.RED);
            button_select.setText("X");
            Active_player = 2;
            button_select.setBackgroundColor(Color.rgb(255,228,181));
            textView4.setText("TURN");
            textView3.setText("");
            textView4.setTextColor(Color.GREEN);
        } else if (Active_player == 2) {
            player2.add(ID);
            button_select.setTextColor(Color.GREEN);
            button_select.setText("O");
            Active_player = 1;
            button_select.setBackgroundColor(Color.rgb(255,239,213));
            textView3.setText("TURN");
            textView4.setText("");
            textView3.setTextColor(Color.RED);
        }
    }

    void check_winner(){
        if (player1.contains(1) && player1.contains(2) && player1.contains(3))
            winner = 1;
        if (player2.contains(1) && player2.contains(2) && player2.contains(3))
            winner = 2;

        if (player1.contains(4) && player1.contains(5) && player1.contains(6))
            winner = 1;
        if (player2.contains(4) && player2.contains(5) && player2.contains(6))
            winner = 2;

        if (player1.contains(7) && player1.contains(8) && player1.contains(9))
            winner = 1;
        if (player2.contains(7) && player2.contains(8) && player2.contains(9))
            winner = 2;

        if (player1.contains(1) && player1.contains(4) && player1.contains(7))
            winner = 1;
        if (player2.contains(1) && player2.contains(4) && player2.contains(7))
            winner = 2;

        if (player1.contains(2) && player1.contains(5) && player1.contains(8))
            winner = 1;
        if (player2.contains(2) && player2.contains(5) && player2.contains(8))
            winner = 2;

        if (player1.contains(3) && player1.contains(6) && player1.contains(9))
            winner = 1;
        if (player2.contains(3) && player2.contains(6) && player2.contains(9))
            winner = 2;

        if (player1.contains(1) && player1.contains(5) && player1.contains(9))
            winner = 1;
        if (player2.contains(1) && player2.contains(5) && player2.contains(9))
            winner = 2;

        if (player1.contains(3) && player1.contains(5) && player1.contains(7))
            winner = 1;
        if (player2.contains(3) && player2.contains(5) && player2.contains(7))
            winner = 2;

        if(counter > 9 && winner == 0)
            finish("Game Over !");
        else if (winner == 1) {
            finish("Player 1 is Winner");
            textView3.setText("Winner");
            textView4.setText("");
        }
        else if (winner == 2) {
            finish("Player 2 is Winner");
            textView4.setText("Winner");
            textView3.setText("");
        }
    }

    public void finish(String str){
        LayoutInflater myLayoutInflater = getLayoutInflater();
        View viewed = myLayoutInflater.inflate(R.layout.winner,null);
        TextView textView;
        textView = (TextView) viewed.findViewById(R.id.textView);
        textView.setText(str);
        textView.setTextSize(36);
        Toast toast = new Toast(getApplicationContext());
        toast.setView(viewed);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setGravity(Gravity.CENTER_VERTICAL,0,0);
        toast.show();
    }

}
